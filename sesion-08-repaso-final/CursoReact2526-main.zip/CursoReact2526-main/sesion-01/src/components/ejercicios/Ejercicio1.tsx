import React from 'react'

interface Producto {
  id: number,
  nombre: string,
  precio: number,
  disponible: boolean,
  categoria?: string
}

function calcularTotal(productos: Producto[]):number {
  
}



const Ejercicio1 = () => {
  return (
    <div>Ejercicio1</div>
  )
}

export default Ejercicio1