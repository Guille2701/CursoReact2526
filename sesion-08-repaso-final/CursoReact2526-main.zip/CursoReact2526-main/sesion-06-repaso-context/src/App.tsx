import React from "react";
import Bisabuelo from "./components/Bisabuelo";

const App = () => {
  return <div><Bisabuelo /></div>;
};

export default App;
