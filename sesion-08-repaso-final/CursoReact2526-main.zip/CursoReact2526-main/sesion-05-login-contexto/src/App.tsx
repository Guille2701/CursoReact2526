import React from 'react'

const App = () => {
  return (
    <div className='text-6xl'>App</div>
  )
}

export default App