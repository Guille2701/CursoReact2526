
const App = () => {
  return (
    <div className='text-6xl text-red-900'>
      

    </div>
  )
}

export default App