
const Home = () => {
  return (
    <div>Home 03 parametros dinámicos</div>
  )
}

export default Home