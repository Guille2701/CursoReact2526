
const PublicHome = () => {
  return (
    <div>PublicHome</div>
  )
}

export default PublicHome