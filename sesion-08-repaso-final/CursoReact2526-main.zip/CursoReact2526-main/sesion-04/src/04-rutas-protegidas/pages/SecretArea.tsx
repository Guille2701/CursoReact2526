
const SecretArea = () => {
  return <div>SecretArea</div>;
};

export default SecretArea;
