
const BuscarPlato = () => {
  return <div>BuscarPlato</div>;
};

export default BuscarPlato;
